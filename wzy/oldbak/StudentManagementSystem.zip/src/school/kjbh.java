package school;

public class kjbh {

	public static void main(String[] args) {
		// TODO 自动生成的方法存根

	}

}
