package school;

public class Score {
    String studentId;
    String courseId;
    double scoreValue;

    public Score(String studentId, String courseId, double scoreValue) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.scoreValue = scoreValue;
    }
}
