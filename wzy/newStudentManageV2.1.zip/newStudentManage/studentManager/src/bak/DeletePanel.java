//package view;
//
//import javax.swing.*;
//
//import controller.StudentController;
//
//import java.awt.*;
//
//// 删除面板类，目前简单构建一个表示“操作记录”的面板，后续可根据实际需求完善功能相关界面
//public class DeletePanel {
//
//    private JPanel panel;
//
//    public DeletePanel() {
//        panel = new JPanel();
//        panel.setLayout(new BorderLayout());
//        JLabel label = new JLabel("操作记录", JLabel.CENTER);
//        panel.add(label, BorderLayout.CENTER);
//    }
//
////    // 更新查询面板的学生列表
////    public void updateStudentTable() {
////        StudentController controller = new StudentController(this);
////        controller.loadStudentData();
////    }
//    public JPanel getPanel() {
//        return panel;
//    }
//}
package bak;

