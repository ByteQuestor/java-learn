package view;
//
import javax.swing.*;
import java.awt.*;
//
//// 更新面板类，目前简单构建一个表示“开发中”的面板，后续可完善具体更新功能相关界面
public class UpdatePanel {

    private JPanel panel;

    public UpdatePanel() {
        panel = new JPanel();
        panel.setLayout(new BorderLayout());
        JLabel label = new JLabel("开发中", JLabel.CENTER);
        panel.add(label, BorderLayout.CENTER);
    }

    public JPanel getPanel() {
        return panel;
    }
}

