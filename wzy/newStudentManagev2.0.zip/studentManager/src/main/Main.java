package main;

//import controller.BindView;
//import controller.StudentController;
import view.Login;
//import view.StudentManagerView;

public class Main {
    public static void main(String[] args) {
    	new Login().setVisible(true);
    }
}