package main;

import view.LibraryLoginFrame;

public class Main {
    public static void main(String[] args) {
        // 创建并显示登录窗口
        new LibraryLoginFrame();
    }
}
