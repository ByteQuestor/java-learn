package main;

import view.FormFactory;

public class Main {
    public static void main(String[] args) {
        // 创建并显示登录窗口
        new FormFactory();
    }
}
